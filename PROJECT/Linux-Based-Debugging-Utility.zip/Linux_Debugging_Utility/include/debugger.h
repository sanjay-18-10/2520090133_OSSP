#ifndef DEBUGGER_H
#define DEBUGGER_H

int debug_program(int argc, char *argv[]);
int debug_c_source(const char *source_path);

#endif

#ifndef DEBUGGER_H
#define DEBUGGER_H

int debug_program(int argc, char *argv[]);

#endif

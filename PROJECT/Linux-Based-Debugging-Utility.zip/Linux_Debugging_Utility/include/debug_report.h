#ifndef DEBUG_REPORT_H
#define DEBUG_REPORT_H
void show_debug_report(void);
#endif

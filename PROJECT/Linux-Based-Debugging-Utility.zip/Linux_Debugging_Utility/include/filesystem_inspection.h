#ifndef FILESYSTEM_INSPECTION_H
#define FILESYSTEM_INSPECTION_H

void show_filesystem_inspection(void);

#endif

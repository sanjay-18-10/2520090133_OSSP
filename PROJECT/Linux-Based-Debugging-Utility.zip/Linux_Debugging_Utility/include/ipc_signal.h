#ifndef IPC_SIGNAL_H
#define IPC_SIGNAL_H

void run_ipc_signal_demo(void);

#endif

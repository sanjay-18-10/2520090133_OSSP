# CO1–CO6 Mapping Template

**Important:** The project PPT does not provide the official CO1–CO6 statements. Fill in the exact statements from the course handout/LMS before submitting. The suggested evidence below is a project feature inventory, not an official CO mapping.

| Course Outcome | Paste exact official CO statement here | Project implementation/evidence (choose after checking the official CO) | Demonstration/evidence |
|---|---|---|---|
| CO1 | [Insert exact statement] | C programming, compilation, command-line arguments | `make`; show source and executable |
| CO2 | [Insert exact statement] | Process creation with `fork()` | Explain parent and child PID |
| CO3 | [Insert exact statement] | Program execution using `execvp()` | Run `./debugutil ./samples/normal` |
| CO4 | [Insert exact statement] | Process synchronization and status using pipe + `waitpid()` | Explain execution gate and exit status |
| CO5 | [Insert exact statement] | Signals and abnormal termination reporting | Run `segfault` and `abort` samples |
| CO6 | [Insert exact statement] | `/proc` process information, testing, report and limitations | Show `/proc` fields and compare test outcomes |

## Evidence to collect for your review
1. Screenshot of successful compilation (`make`).
2. Screenshot of normal target output.
3. Screenshot of non-zero exit code.
4. Screenshot of signal-based abnormal termination.
5. Screenshot of `/proc` information.
6. Short explanation of the limitations and why GDB is still useful.

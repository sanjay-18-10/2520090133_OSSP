#include <stdio.h>
#include <unistd.h>
#include <sys/utsname.h>
#include "system_info.h"

void show_system_information(void) {
    struct utsname info;
    char hostname[256] = "Unknown";
    char line[256];

    printf("\n========== LINUX SYSTEM INFORMATION ==========\n");

    if (uname(&info) == 0) {
        printf("Operating system : %s\n", info.sysname);
        printf("Kernel release   : %s\n", info.release);
        printf("Machine type     : %s\n", info.machine);
        printf("Kernel version   : %s\n", info.version);
    }

    if (gethostname(hostname, sizeof(hostname)) == 0)
        printf("Hostname         : %s\n", hostname);

    printf("Online CPU cores : %ld\n", sysconf(_SC_NPROCESSORS_ONLN));

    FILE *file = fopen("/proc/uptime", "r");
    if (file != NULL) {
        double uptime_seconds;
        if (fscanf(file, "%lf", &uptime_seconds) == 1)
            printf("System uptime    : %.0f seconds\n", uptime_seconds);
        fclose(file);
    }

    file = fopen("/proc/loadavg", "r");
    if (file != NULL) {
        if (fgets(line, sizeof(line), file))
            printf("System load      : %s", line);
        fclose(file);
    }

    printf("===============================================\n");
}

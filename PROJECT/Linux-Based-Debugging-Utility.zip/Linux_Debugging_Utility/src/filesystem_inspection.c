#include <stdio.h>
#include <sys/statvfs.h>
#include <sys/stat.h>
#include "filesystem_inspection.h"

void show_filesystem_inspection(void) {
    struct statvfs info;
    struct stat file_info;
    unsigned long long total;
    unsigned long long available;
    unsigned long long used;

    printf("\n========== FILE SYSTEM INSPECTION ==========\n");

    if (statvfs(".", &info) != 0) {
        perror("Filesystem inspection failed");
        return;
    }

    total = (unsigned long long)info.f_blocks * info.f_frsize;
    available = (unsigned long long)info.f_bavail * info.f_frsize;
    used = total - ((unsigned long long)info.f_bfree * info.f_frsize);

    printf("Inspected path : Current project directory\n");
    printf("Total space    : %llu MB\n", total / (1024 * 1024));
    printf("Used space     : %llu MB\n", used / (1024 * 1024));
    printf("Available space: %llu MB\n", available / (1024 * 1024));

    if (stat(".", &file_info) == 0) {
        printf("Directory inode: %lu\n",
               (unsigned long)file_info.st_ino);
        printf("Permissions    : %o\n",
               (unsigned int)(file_info.st_mode & 0777));
    }

    printf("============================================\n");
}

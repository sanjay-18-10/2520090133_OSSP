#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "debugger.h"
#include "process_monitor.h"
#include "ipc_signal.h"
#include "memory_analysis.h"
#include "filesystem_inspection.h"
#include "debug_report.h"
#include "system_info.h"
#include "thread_debugging.h"

static void clear_input(void) {
    int ch;
    while ((ch = getchar()) != '\n' && ch != EOF) {}
}

static void show_menu(void) {
    printf("\n============================================\n");
    printf("       LINUX-BASED DEBUGGING UTILITY\n");
    printf("============================================\n");
    printf("1. Debug a Program\n");
    printf("2. Process Monitoring\n");
    printf("3. IPC and Signal Debugging\n");
    printf("4. Memory Analysis\n");
    printf("5. File System Inspection\n");
    printf("6. Thread and Synchronization Debugging\n");
    printf("7. Linux System Information\n");
    printf("8. View Debugging Reports\n");
    printf("0. Exit\n");
    printf("============================================\n");
    printf("Enter your choice: ");
}

static void debug_menu(void) {
    int selection;
    char source_path[512];
    char *target = NULL;

    printf("\n========== SELECT TARGET PROGRAM ==========\n");
    printf("1. Normal exit sample\n");
    printf("2. Segmentation fault sample\n");
    printf("3. Abort signal sample\n");
    printf("4. Non-zero exit sample\n");
    printf("5. Debug my own C source file\n");
    printf("0. Return to main menu\n");
    printf("Choose an option: ");

    if (scanf("%d", &selection) != 1) {
        printf("Invalid input.\n");
        clear_input();
        return;
    }
    clear_input();

    switch (selection) {
        case 1: target = "./samples/normal"; break;
        case 2: target = "./samples/segfault"; break;
        case 3: target = "./samples/abort"; break;
        case 4: target = "./samples/nonzero_exit"; break;
        case 5:
            printf("Enter the path to your C source file: ");
            if (!fgets(source_path, sizeof(source_path), stdin)) {
                printf("Could not read the file path.\n");
                return;
            }
            source_path[strcspn(source_path, "\n")] = '\0';

            if (source_path[0] == '\0') {
                printf("File path cannot be empty.\n");
                return;
            }

            debug_c_source(source_path);
            return;

        case 0: return;
        default:
            printf("Invalid selection.\n");
            return;
    }

    char *args[] = {"linux-debugger", target, NULL};
    printf("\nStarting program debugger...\n");
    debug_program(2, args);
}

int main(void) {
    int choice;

    while (1) {
        show_menu();

        if (scanf("%d", &choice) != 1) {
            printf("\nInvalid input. Please enter a number.\n");
            clear_input();
            continue;
        }
        clear_input();

        switch (choice) {
            case 1:
                debug_menu();
                break;
            case 2:
                show_process_monitor();
                break;
            case 3:
                run_ipc_signal_demo();
                break;
            case 4:
                show_memory_analysis();
                break;
            case 5:
                show_filesystem_inspection();
                break;
            case 6:
                run_thread_debugging();
                break;
            case 7:
                show_system_information();
                break;
            case 8:
                show_debug_report();
                break;
            case 0:
                printf("\nExiting Linux-Based Debugging Utility.\n");
                return 0;
            default:
                printf("\nInvalid choice. Please try again.\n");
        }

        printf("\nPress Enter to return to the main menu...");
        getchar();
    }

    return 0;
}

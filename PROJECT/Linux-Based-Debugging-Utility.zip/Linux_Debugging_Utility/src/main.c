#include <stdio.h>
#include <stdlib.h>
#include "debugger.h"
#include "process_monitor.h"
#include "ipc_signal.h"
#include "memory_analysis.h"
#include "filesystem_inspection.h"\n#include "debug_report.h"\n#include "system_info.h"\n#include "thread_debugging.h"

static void show_menu(void) {
    printf("\n");
    printf("============================================\n");
    printf("       LINUX-BASED DEBUGGING UTILITY\n");
    printf("============================================\n");
    printf("1. Debug a Program\n");
    printf("2. Process Monitoring\n");
    printf("3. IPC and Signal Debugging\n");
    printf("4. Memory Analysis\n");
    printf("5. File System Inspection\n");
    printf("6. Thread and Synchronization Debugging\n");
    printf("7. Linux System Information\n");
    printf("8. View Debugging Reports\n");
    printf("0. Exit\n");
    printf("============================================\n");
    printf("Enter your choice: ");
}

int main(void) {
    int choice;

    while (1) {
        show_menu();

        if (scanf("%d", &choice) != 1) {
            printf("\nInvalid input. Please enter a number.\n");
            int ch;
            while ((ch = getchar()) != '\n' && ch != EOF) {}
            continue;
        }

        switch (choice) {
            case 1: {
                int sample_choice;
                char *target = NULL;

                printf("\n========== SELECT TARGET PROGRAM ==========\n");
                printf("1. Normal exit\n");
                printf("2. Segmentation fault\n");
                printf("3. Abort signal\n");
                printf("4. Non-zero exit\n");
                printf("0. Return to main menu\n");
                printf("Choose a test program: ");

                if (scanf("%d", &sample_choice) != 1) {
                    printf("Invalid input.\n");
                    int ch;
                    while ((ch = getchar()) != '\n' && ch != EOF) {}
                    break;
                }

                while (getchar() != '\n') {}

                switch (sample_choice) {
                    case 1: target = "./samples/normal"; break;
                    case 2: target = "./samples/segfault"; break;
                    case 3: target = "./samples/abort"; break;
                    case 4: target = "./samples/nonzero_exit"; break;
                    case 0: break;
                    default:
                        printf("Invalid selection.\n");
                        break;
                }

                if (target != NULL) {
                    char *args[] = {"linux-debugger", target, NULL};
                    printf("\nStarting program debugger...\n");
                    debug_program(2, args);
                }
                break;
            }

            case 2:
                show_process_monitor();
                break;

            case 3:
                run_ipc_signal_demo();
                break;

            case 4:
                show_memory_analysis();
                break;

            case 5:
                show_filesystem_inspection();
                break;

            case 6:
                run_thread_debugging();
                break;

            case 7:
                show_system_information();
                break;

            case 8:
                show_debug_report();
                break;

            case 0:
                printf("\nExiting Linux-Based Debugging Utility.\n");
                return 0;

            default:
                printf("\nInvalid choice. Please try again.\n");
        }

        printf("\nPress Enter to return to the main menu...");
        int ch;
        while ((ch = getchar()) != '\n' && ch != EOF) {}
        getchar();
    }

    return 0;
}

#include <stdio.h>\n#include <string.h>
#include <time.h>
#include <dirent.h>
#include <sys/utsname.h>
#include <sys/statvfs.h>
#include "debug_report.h"

void show_debug_report(void) {
    FILE *report;
    DIR *proc;
    struct dirent *entry;
    struct utsname system;
    struct statvfs disk;
    int process_count = 0;
    char line[256];

    report = fopen("reports/debugging_report.txt", "w");
    if (report == NULL) {
        perror("Unable to create report");
        return;
    }

    time_t now = time(NULL);
    fprintf(report, "LINUX DEBUGGING UTILITY - SYSTEM REPORT\n");
    fprintf(report, "========================================\n");
    fprintf(report, "Generated: %s", ctime(&now));

    if (uname(&system) == 0) {
        fprintf(report, "\nSYSTEM INFORMATION\n");
        fprintf(report, "OS: %s\nKernel: %s\nMachine: %s\n",
                system.sysname, system.release, system.machine);
    }

    fprintf(report, "\nMEMORY INFORMATION\n");
    FILE *memory = fopen("/proc/meminfo", "r");
    if (memory != NULL) {
        while (fgets(line, sizeof(line), memory)) {
            if (strncmp(line, "MemTotal:", 9) == 0 ||
                strncmp(line, "MemAvailable:", 13) == 0 ||
                strncmp(line, "SwapTotal:", 10) == 0 ||
                strncmp(line, "SwapFree:", 9) == 0)
                fprintf(report, "%s", line);
        }
        fclose(memory);
    }

    fprintf(report, "\nFILESYSTEM INFORMATION\n");
    if (statvfs(".", &disk) == 0) {
        unsigned long long total =
            (unsigned long long)disk.f_blocks * disk.f_frsize;
        unsigned long long free_space =
            (unsigned long long)disk.f_bavail * disk.f_frsize;
        fprintf(report, "Total: %llu MB\n",
                total / (1024 * 1024));
        fprintf(report, "Available: %llu MB\n",
                free_space / (1024 * 1024));
    }

    proc = opendir("/proc");
    if (proc != NULL) {
        while ((entry = readdir(proc)) != NULL) {
            if (entry->d_name[0] >= '0' &&
                entry->d_name[0] <= '9')
                process_count++;
        }
        closedir(proc);
    }

    fprintf(report, "\nPROCESS INFORMATION\n");
    fprintf(report, "Visible process entries: %d\n", process_count);
    fprintf(report, "\nReport generated successfully.\n");
    fclose(report);

    printf("\n========== DEBUGGING REPORT ==========\n");
    report = fopen("reports/debugging_report.txt", "r");
    if (report != NULL) {
        while (fgets(line, sizeof(line), report))
            printf("%s", line);
        fclose(report);
    }
    printf("Saved at: reports/debugging_report.txt\n");
    printf("======================================\n");
}

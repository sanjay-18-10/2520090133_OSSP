#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <dirent.h>
#include <ctype.h>
#include <string.h>
#include "process_monitor.h"

void show_process_monitor(void) {
    DIR *directory;
    struct dirent *entry;
    char path[512];
    char line[512];

    printf("\n========== PROCESS MONITORING ==========\n");
    printf("%-10s %-10s %-10s %s\n", "PID", "PPID", "STATE", "PROCESS");

    directory = opendir("/proc");

    if (directory == NULL) {
        perror("Unable to open /proc");
        return;
    }

    while ((entry = readdir(directory)) != NULL) {
        if (!isdigit((unsigned char)entry->d_name[0]))
            continue;

        snprintf(path, sizeof(path), "/proc/%s/status", entry->d_name);

        FILE *file = fopen(path, "r");
        if (file == NULL)
            continue;

        char name[256] = "Unknown";
        char state[32] = "?";
        char ppid[32] = "?";

        while (fgets(line, sizeof(line), file)) {
            if (strncmp(line, "Name:", 5) == 0)
                sscanf(line + 5, "%255s", name);
            else if (strncmp(line, "State:", 6) == 0)
                sscanf(line + 6, "%31s", state);
            else if (strncmp(line, "PPid:", 5) == 0)
                sscanf(line + 5, "%31s", ppid);
        }

        fclose(file);

        printf("%-10s %-10s %-10s %s\n",
               entry->d_name, ppid, state, name);
    }

    closedir(directory);
    printf("========================================\n");
}

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <signal.h>
#include <sys/wait.h>
#include <string.h>
#include "ipc_signal.h"

void handle_signal(int signal_number) {
    printf("\nSignal received successfully! Signal number: %d\n",
           signal_number);
}

void run_ipc_signal_demo(void) {
    int pipefd[2];
    pid_t pid;
    char message[] = "Hello from parent process!";
    char buffer[100];

    printf("\n========== IPC AND SIGNAL DEBUGGING ==========\n");

    if (pipe(pipefd) == -1) {
        perror("Pipe creation failed");
        return;
    }

    pid = fork();

    if (pid < 0) {
        perror("Fork failed");
        close(pipefd[0]);
        close(pipefd[1]);
        return;
    }

    if (pid == 0) {
        close(pipefd[1]);

        read(pipefd[0], buffer, sizeof(buffer));
        printf("Child received message: %s\n", buffer);

        close(pipefd[0]);
        exit(EXIT_SUCCESS);
    } else {
        close(pipefd[0]);

        write(pipefd[1], message, strlen(message) + 1);
        printf("Parent sent message through pipe.\n");

        close(pipefd[1]);
        waitpid(pid, NULL, 0);
    }

    signal(SIGUSR1, handle_signal);
    printf("Sending SIGUSR1 to the current process...\n");
    raise(SIGUSR1);

    printf("IPC and signal demonstration completed.\n");
    printf("==============================================\n");
}

#define _POSIX_C_SOURCE 200809L
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

static void show_process_info(pid_t pid) {
    char path[128];
    char line[256];
    snprintf(path, sizeof(path), "/proc/%ld/status", (long)pid);
    FILE *fp = fopen(path, "r");
    if (!fp) {
        fprintf(stderr, "Note: could not read %s: %s\n", path, strerror(errno));
        return;
    }

    puts("\n--- Selected information from /proc ---");
    while (fgets(line, sizeof(line), fp)) {
        if (!strncmp(line, "Name:", 5) ||
            !strncmp(line, "State:", 6) ||
            !strncmp(line, "Pid:", 4) ||
            !strncmp(line, "PPid:", 5) ||
            !strncmp(line, "VmPeak:", 7) ||
            !strncmp(line, "VmRSS:", 6) ||
            !strncmp(line, "Threads:", 8)) {
            fputs(line, stdout);
        }
    }
    fclose(fp);
}

static const char *signal_description(int sig) {
    switch (sig) {
        case SIGSEGV: return "Segmentation fault (invalid memory access)";
        case SIGABRT: return "Abort signal (program called abort or assertion failed)";
        case SIGFPE:  return "Arithmetic exception (for example, integer divide by zero)";
        case SIGILL:  return "Illegal instruction";
        case SIGBUS:  return "Bus error";
        case SIGTERM: return "Termination requested (SIGTERM)";
        case SIGINT:  return "Interrupted (SIGINT)";
        default:      return strsignal(sig);
    }
}

int debug_program(int argc, char *argv[]) {
    if (argc < 2) {
        fprintf(stderr, "Usage: %s <program> [program arguments...]\n", argv[0]);
        fprintf(stderr, "Example: %s ./samples/normal\n", argv[0]);
        return 2;
    }

    int gate[2];
    if (pipe(gate) == -1) {
        perror("pipe");
        return 1;
    }

    printf("=== Linux-Based Debugging Utility ===\n");
    printf("Target: ");
    for (int i = 1; i < argc; i++) printf("%s%s", argv[i], i + 1 < argc ? " " : "\n");
    fflush(stdout);

    pid_t child = fork();
    if (child == -1) {
        perror("fork");
        close(gate[0]);
        close(gate[1]);
        return 1;
    }

    if (child == 0) {
        close(gate[1]);
        char token;
        ssize_t n;
        do {
            n = read(gate[0], &token, 1);
        } while (n == -1 && errno == EINTR);
        close(gate[0]);
        if (n != 1) {
            fprintf(stderr, "Child: failed to receive execution signal\n");
            _exit(125);
        }
        execvp(argv[1], &argv[1]);
        fprintf(stderr, "execvp failed for '%s': %s\n", argv[1], strerror(errno));
        _exit(errno == ENOENT ? 127 : 126);
    }

    close(gate[0]);
    printf("Child PID: %ld\n", (long)child);
    show_process_info(child);

    /* Release the child only after attempting to collect /proc information. */
    char token = 'G';
    if (write(gate[1], &token, 1) != 1) {
        perror("write");
        close(gate[1]);
        kill(child, SIGTERM);
        waitpid(child, NULL, 0);
        return 1;
    }
    close(gate[1]);

    int status;
    pid_t result;
    do {
        result = waitpid(child, &status, 0);
    } while (result == -1 && errno == EINTR);

    if (result == -1) {
        perror("waitpid");
        return 1;
    }

    puts("\n--- Debugging report ---");
    printf("Target PID: %ld\n", (long)child);
    if (WIFEXITED(status)) {
        int code = WEXITSTATUS(status);
        printf("Termination: normal exit\nExit code: %d\n", code);
        if (code == 0) puts("Result: target completed successfully.");
        else puts("Result: target exited with a non-zero status; inspect its output and exit code.");
        return code == 0 ? 0 : 1;
    }

    if (WIFSIGNALED(status)) {
        int sig = WTERMSIG(status);
        printf("Termination: signal %d (%s)\n", sig, strsignal(sig));
        printf("Likely interpretation: %s\n", signal_description(sig));
        puts("Result: target terminated abnormally.");
        return 1;
    }

    puts("Termination: status could not be classified.");
    return 1;
}


int debug_c_source(const char *source_path) {
    if (!source_path || !*source_path) {
        fprintf(stderr, "No source file path provided.\n");
        return 1;
    }

    printf("\n========== COMPILING C PROGRAM ==========\n");
    printf("Source file: %s\n", source_path);

    pid_t compiler = fork();
    if (compiler == -1) {
        perror("fork");
        return 1;
    }

    if (compiler == 0) {
        execlp("gcc", "gcc", "-Wall", "-Wextra", "-g", "-O0",
               source_path, "-o", "bin/custom_program", (char *)NULL);
        perror("gcc");
        _exit(127);
    }

    int status;
    pid_t result;
    do {
        result = waitpid(compiler, &status, 0);
    } while (result == -1 && errno == EINTR);

    if (result == -1) {
        perror("waitpid");
        return 1;
    }

    if (!WIFEXITED(status) || WEXITSTATUS(status) != 0) {
        printf("\nCompilation failed. Check the GCC errors above.\n");
        return 1;
    }

    printf("Compilation successful!\n");
    printf("\nStarting your program under the debugger...\n");

    char *args[] = {"linux-debugger", "./bin/custom_program", NULL};
    return debug_program(2, args);
}

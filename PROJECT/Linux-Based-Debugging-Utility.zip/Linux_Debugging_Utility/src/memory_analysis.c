#include <stdio.h>
#include <string.h>
#include "memory_analysis.h"

void show_memory_analysis(void) {
    FILE *file;
    char line[256];

    printf("\n========== MEMORY ANALYSIS ==========\n");

    printf("\nSYSTEM MEMORY INFORMATION\n");

    file = fopen("/proc/meminfo", "r");

    if (file == NULL) {
        perror("Unable to read system memory");
        return;
    }

    while (fgets(line, sizeof(line), file)) {
        if (strncmp(line, "MemTotal:", 9) == 0 ||
            strncmp(line, "MemFree:", 8) == 0 ||
            strncmp(line, "MemAvailable:", 13) == 0 ||
            strncmp(line, "SwapTotal:", 10) == 0 ||
            strncmp(line, "SwapFree:", 9) == 0) {
            printf("%s", line);
        }
    }

    fclose(file);

    printf("\nCURRENT PROCESS MEMORY\n");

    file = fopen("/proc/self/status", "r");

    if (file == NULL) {
        perror("Unable to read process memory");
        return;
    }

    while (fgets(line, sizeof(line), file)) {
        if (strncmp(line, "VmPeak:", 7) == 0 ||
            strncmp(line, "VmSize:", 7) == 0 ||
            strncmp(line, "VmRSS:", 6) == 0 ||
            strncmp(line, "VmData:", 7) == 0 ||
            strncmp(line, "VmStk:", 6) == 0) {
            printf("%s", line);
        }
    }

    fclose(file);

    printf("=====================================\n");
}

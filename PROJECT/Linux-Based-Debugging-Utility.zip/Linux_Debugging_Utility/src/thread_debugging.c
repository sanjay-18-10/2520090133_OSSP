#include <stdio.h>
#include <pthread.h>
#include "thread_debugging.h"

#define THREAD_COUNT 4
#define ITERATIONS 100000

static pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;
static long counter = 0;

static void *worker(void *arg) {
    (void)arg;
    for (int i = 0; i < ITERATIONS; i++) {
        pthread_mutex_lock(&lock);
        counter++;
        pthread_mutex_unlock(&lock);
    }
    return NULL;
}

void run_thread_debugging(void) {
    pthread_t threads[THREAD_COUNT];
    int created = 0;

    printf("\n========== THREAD AND SYNCHRONIZATION ==========\n");

    for (int i = 0; i < THREAD_COUNT; i++) {
        if (pthread_create(&threads[i], NULL, worker, NULL) != 0) {
            perror("Thread creation failed");
            break;
        }
        created++;
    }

    for (int i = 0; i < created; i++)
        pthread_join(threads[i], NULL);

    printf("Threads created       : %d\n", created);
    printf("Iterations per thread : %d\n", ITERATIONS);
    printf("Final shared counter  : %ld\n", counter);
    printf("Expected counter      : %d\n", created * ITERATIONS);
    printf("Mutex protected shared resource successfully.\n");

    pthread_mutex_destroy(&lock);
    printf("================================================\n");
}

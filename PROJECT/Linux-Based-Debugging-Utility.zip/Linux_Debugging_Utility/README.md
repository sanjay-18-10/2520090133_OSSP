# Linux-Based Debugging Utility

A beginner-friendly C project for Ubuntu demonstrating Linux process management and basic runtime-failure reporting.

## 1. Requirements
- Ubuntu Linux (native install, VM, or WSL)
- GCC and `make`
- A terminal

Install tools:
```bash
sudo apt update
sudo apt install build-essential
```

## 2. Build
Open a terminal in this folder:
```bash
make
```
Check that the executable exists:
```bash
ls -l debugutil samples/
```

## 3. Run tests
Normal execution:
```bash
./debugutil ./samples/normal
```
Non-zero exit:
```bash
./debugutil ./samples/nonzero_exit
```
Segmentation fault (intentional test):
```bash
./debugutil ./samples/segfault
```
Abort signal (intentional test):
```bash
./debugutil ./samples/abort
```
These two failure samples are deliberately unsafe and should only be run as local test programs in this project folder.

Run a system command as a target:
```bash
./debugutil /bin/echo Hello from Ubuntu
```

## 4. What the implementation demonstrates
- `fork()` creates a child process.
- `execvp()` replaces the child process image with the requested target program.
- `waitpid()` waits for the child and reads its termination status.
- `WIFEXITED`, `WEXITSTATUS`, `WIFSIGNALED`, and `WTERMSIG` interpret that status.
- Signals such as `SIGSEGV` and `SIGABRT` are reported if they terminate the child.
- `/proc/<pid>/status` is read before the child is released to execute, so selected process information can be captured reliably.
- A pipe briefly synchronizes the child and parent, ensuring the `/proc` inspection happens before `execvp()`.

## 5. Important limitations
This is a process-monitoring and failure-reporting utility, not a full debugger. It does not identify the exact source line for a fault, inspect variables, or provide a timeout for infinite loops. Use GDB for line-level debugging. The utility only reports signals that actually terminate the target; it cannot reliably detect every logical bug.

## 6. Troubleshooting
- `gcc: command not found`: run `sudo apt install build-essential`.
- `make: command not found`: install `build-essential`.
- `Permission denied`: run `chmod +x debugutil` (normally not needed after `make`).
- `execvp failed`: check the target path and ensure it exists. Use `./` for a program in the current directory.
- `Segmentation fault` test does not crash on a particular environment: compiler/OS behavior can vary; rebuild with `make clean && make`.

## 7. CO1–CO6 mapping
The supplied PPT explains the project and its APIs but does not state the official wording of CO1, CO2, CO3, CO4, CO5, and CO6. Do not submit a guessed mapping. Obtain the exact CO statements from your course handout/LMS and map each one to the relevant implementation, test, evidence, and explanation. A starter template is in `docs/CO1-CO6-mapping.md`.

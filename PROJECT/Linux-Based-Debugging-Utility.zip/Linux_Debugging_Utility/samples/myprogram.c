#include <stdio.h>

int main(void) {
    printf("Hello Linux Debugger!\n");
    return 0;
}

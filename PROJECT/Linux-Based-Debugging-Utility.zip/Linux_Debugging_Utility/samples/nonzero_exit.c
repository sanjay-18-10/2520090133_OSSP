#include <stdio.h>
int main(void) {
    puts("This program deliberately exits with status 7.");
    return 7;
}

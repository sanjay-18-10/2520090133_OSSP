#include <stdio.h>
#include <stdlib.h>
int main(void) {
    puts("About to call abort()...");
    fflush(stdout);
    abort(); /* Intentionally terminates abnormally: test only. */
}

#include <stdio.h>
int main(void) {
    puts("About to perform an invalid memory access...");
    fflush(stdout);
    volatile int *p = (int *)0;
    *p = 42; /* Intentionally invalid: test only. */
    return 0;
}

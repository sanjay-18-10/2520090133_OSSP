#include <stdio.h>
int main(void) {
    puts("Hello from the target program.");
    puts("This program will exit normally with code 0.");
    return 0;
}
